export interface Team {
    name: string,
    picture: string
}
