export interface Features{
    title: string,
    body: string,
    image:string
}